﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            //Pegar da tela
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            //Processamento (fazer contas!)
            soma = num1 + num3;

            //Saída 
            lblRSoma.Text = "Soma igual a " + soma;
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            //Pegar da tela
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;

            //Processamento 
            media = (num1 + num2 + num3) / 3;

            //Saída
            lblRMedia.Text = "Media igual a " + media;
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            //A porcentagem de cada número em relação ao total
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float total, porcNum1, porcNum2, porcNum3;

            //Processamento
            total = num1 + num2 + num3; //100%
            porcNum1 = num1 / total * 100;
            porcNum2 = num2 / total * 100;
            porcNum3 = num3 / total * 100;

            //Saída 
            lblRPorcentagem.Text = "Num1 é " + porcNum1 + "% - " + "Num2 é " + porcNum2 + "% -" + "Num3 é " + porcNum3 + "%.";
        }
    }
}
