﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimProva_Michelle_2A2
{
    public partial class FrmQuestao03 : Form
    {
        public FrmQuestao03()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os dados da tela
            float valorCompra = float.Parse(txtValorCompra.Text);
            float valorComDesconto;

            //Calcular
            valorComDesconto = valorCompra - (valorCompra * 12 / 100);

            //Exibir resultado
            lblResultadoDesconto.Text = valorComDesconto.ToString("C");
        }
    }
}
