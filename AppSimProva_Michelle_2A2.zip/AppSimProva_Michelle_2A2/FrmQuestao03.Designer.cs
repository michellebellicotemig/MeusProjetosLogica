﻿namespace AppSimProva_Michelle_2A2
{
    partial class FrmQuestao03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlVerde = new System.Windows.Forms.Panel();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblValorCompra = new System.Windows.Forms.Label();
            this.txtValorCompra = new System.Windows.Forms.TextBox();
            this.pnlAmarelo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlAzul = new System.Windows.Forms.Panel();
            this.lblResultadoDesconto = new System.Windows.Forms.Label();
            this.lblValorDesconto = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.pnlVerde.SuspendLayout();
            this.pnlAmarelo.SuspendLayout();
            this.pnlAzul.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlVerde
            // 
            this.pnlVerde.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(178)))), ((int)(((byte)(154)))));
            this.pnlVerde.Controls.Add(this.btnCalcular);
            this.pnlVerde.Controls.Add(this.lblValorCompra);
            this.pnlVerde.Controls.Add(this.txtValorCompra);
            this.pnlVerde.Location = new System.Drawing.Point(2, 74);
            this.pnlVerde.Name = "pnlVerde";
            this.pnlVerde.Size = new System.Drawing.Size(425, 172);
            this.pnlVerde.TabIndex = 0;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(122)))), ((int)(((byte)(95)))));
            this.btnCalcular.Font = new System.Drawing.Font("Cooper Black", 18F);
            this.btnCalcular.Location = new System.Drawing.Point(54, 81);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(314, 59);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblValorCompra
            // 
            this.lblValorCompra.AutoSize = true;
            this.lblValorCompra.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorCompra.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(64)))), ((int)(((byte)(91)))));
            this.lblValorCompra.Location = new System.Drawing.Point(49, 39);
            this.lblValorCompra.Name = "lblValorCompra";
            this.lblValorCompra.Size = new System.Drawing.Size(145, 25);
            this.lblValorCompra.TabIndex = 1;
            this.lblValorCompra.Text = "Valor da Compra";
            // 
            // txtValorCompra
            // 
            this.txtValorCompra.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorCompra.Location = new System.Drawing.Point(200, 36);
            this.txtValorCompra.Name = "txtValorCompra";
            this.txtValorCompra.Size = new System.Drawing.Size(144, 32);
            this.txtValorCompra.TabIndex = 0;
            // 
            // pnlAmarelo
            // 
            this.pnlAmarelo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(204)))), ((int)(((byte)(143)))));
            this.pnlAmarelo.Controls.Add(this.lblTitulo);
            this.pnlAmarelo.Location = new System.Drawing.Point(2, -8);
            this.pnlAmarelo.Name = "pnlAmarelo";
            this.pnlAmarelo.Size = new System.Drawing.Size(425, 83);
            this.pnlAmarelo.TabIndex = 1;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Cooper Black", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(64)))), ((int)(((byte)(91)))));
            this.lblTitulo.Location = new System.Drawing.Point(23, 32);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(293, 27);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Exercício Porcentagem";
            // 
            // pnlAzul
            // 
            this.pnlAzul.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlAzul.Controls.Add(this.lblResultadoDesconto);
            this.pnlAzul.Controls.Add(this.lblValorDesconto);
            this.pnlAzul.Location = new System.Drawing.Point(2, 234);
            this.pnlAzul.Name = "pnlAzul";
            this.pnlAzul.Size = new System.Drawing.Size(422, 62);
            this.pnlAzul.TabIndex = 2;
            // 
            // lblResultadoDesconto
            // 
            this.lblResultadoDesconto.AutoSize = true;
            this.lblResultadoDesconto.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultadoDesconto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(64)))), ((int)(((byte)(91)))));
            this.lblResultadoDesconto.Location = new System.Drawing.Point(312, 21);
            this.lblResultadoDesconto.Name = "lblResultadoDesconto";
            this.lblResultadoDesconto.Size = new System.Drawing.Size(18, 25);
            this.lblResultadoDesconto.TabIndex = 4;
            this.lblResultadoDesconto.Text = "-";
            // 
            // lblValorDesconto
            // 
            this.lblValorDesconto.AutoSize = true;
            this.lblValorDesconto.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorDesconto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(64)))), ((int)(((byte)(91)))));
            this.lblValorDesconto.Location = new System.Drawing.Point(72, 21);
            this.lblValorDesconto.Name = "lblValorDesconto";
            this.lblValorDesconto.Size = new System.Drawing.Size(174, 25);
            this.lblValorDesconto.TabIndex = 3;
            this.lblValorDesconto.Text = "Valor com desconto:";
            // 
            // FrmQuestao03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 295);
            this.Controls.Add(this.pnlAzul);
            this.Controls.Add(this.pnlAmarelo);
            this.Controls.Add(this.pnlVerde);
            this.Name = "FrmQuestao03";
            this.Text = "FrmQuestao03";
            this.pnlVerde.ResumeLayout(false);
            this.pnlVerde.PerformLayout();
            this.pnlAmarelo.ResumeLayout(false);
            this.pnlAmarelo.PerformLayout();
            this.pnlAzul.ResumeLayout(false);
            this.pnlAzul.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlVerde;
        private System.Windows.Forms.Label lblValorCompra;
        private System.Windows.Forms.TextBox txtValorCompra;
        private System.Windows.Forms.Panel pnlAmarelo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Panel pnlAzul;
        private System.Windows.Forms.Label lblResultadoDesconto;
        private System.Windows.Forms.Label lblValorDesconto;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}